$(function(){
    alert("Hola");
})