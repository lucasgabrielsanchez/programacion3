console.log("Hola Mundo");

//reconoce jQuery
$(function(){
    $('#txt').val("hola mundo");
})