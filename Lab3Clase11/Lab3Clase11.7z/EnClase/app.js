"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Avenger = /** @class */ (function () {
    //el undefined se le coloca para que no chille por el paràmetro opcional que pasamos.
    function Avenger(nombre, nombreReal, peleasGanadas) {
        this._nombre = nombre;
        this.nombreReal = nombreReal;
        this.peleasGanadas = peleasGanadas;
    }
    Object.defineProperty(Avenger.prototype, "Nombre", {
        get: function () {
            return this._nombre;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Avenger.prototype, "SetNombre", {
        set: function (nombre) {
            this._nombre = nombre;
        },
        enumerable: true,
        configurable: true
    });
    Avenger.prototype.mostrar = function () {
        return "Hola " + this._nombre + ", Probando " + this.nombreReal + "," + this.peleasGanadas;
    };
    return Avenger;
}());
var Xmen = /** @class */ (function (_super) {
    __extends(Xmen, _super);
    function Xmen(nombre, nombreReal, poder, peleasGanadas) {
        var _this = _super.call(this, nombre, nombreReal) || this;
        _this._poder = poder;
        return _this;
    }
    Xmen.prototype.mostrar = function () {
        return _super.prototype.mostrar.call(this) + this._poder;
    };
    return Xmen;
}(Avenger));
var a1 = new Avenger("Ironman", "Tony", 10);
var a2 = new Avenger("Hulk", "NombreReal");
// a1.nombreReal = "Tony";
// a1.peleasGanadas = 10;
console.log(a1.mostrar());
console.log(a1);
a1.SetNombre = "NuevoNombre";
console.log(a1.Nombre);
var xmen1 = new Xmen("Carlos", "Rodriguez", "Rayos");
console.log(xmen1);
var arraySuperheroes = new Array();
arraySuperheroes.push(a1);
arraySuperheroes.push(xmen1);
console.log(arraySuperheroes);
var Apocalipsis = /** @class */ (function () {
    function Apocalipsis(nombre) {
        this.nombre = nombre;
    }
    Object.defineProperty(Apocalipsis, "Instance", {
        get: function () {
            if (!(this._instance)) {
                this._instance = new Apocalipsis("HEEELL");
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    return Apocalipsis;
}());
console.log(Apocalipsis.Instance.nombre);
