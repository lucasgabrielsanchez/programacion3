class Avenger
{
    //por default todo es público.
    private _nombre:string;
    nombreReal:string;
    peleasGanadas:number|undefined;

    get Nombre():string{
        return this._nombre;
    }

    set SetNombre(nombre:string){
        this._nombre = nombre;
    }

    //el undefined se le coloca para que no chille por el paràmetro opcional que pasamos.
    constructor(nombre:string, nombreReal:string, peleasGanadas?:number|undefined)
    {
        this._nombre = nombre;
        this.nombreReal = nombreReal;
        this.peleasGanadas = peleasGanadas;
    }

    mostrar():string{
        return `Hola ${this._nombre}, Probando ${this.nombreReal},${this.peleasGanadas}`;
    }
}

class Xmen extends Avenger
{
    private _poder:string;

    constructor(nombre:string, nombreReal:string, poder:string, peleasGanadas?:number|undefined) 
    {
        super(nombre,nombreReal);
        this._poder = poder;
    }

    mostrar():string{
        return super.mostrar() + this._poder;
    }

}

let a1 = new Avenger("Ironman","Tony",10);
let a2 = new Avenger("Hulk","NombreReal");
// a1.nombreReal = "Tony";
// a1.peleasGanadas = 10;

console.log(a1.mostrar());

console.log(a1);

a1.SetNombre = "NuevoNombre";

console.log(a1.Nombre);

let xmen1=new Xmen("Carlos","Rodriguez","Rayos");

console.log(xmen1);

let arraySuperheroes = new Array<Avenger>();
arraySuperheroes.push(a1);
arraySuperheroes.push(xmen1);

console.log(arraySuperheroes);

class Apocalipsis
{
    //patrón de diseño "Singleton", oculta el constructor y provoca que solo instanciemos 1 objeto de la clase
    //en el examen no se toma.
    private static _instance:Apocalipsis;

    private constructor(public nombre:string)//con public nombre:string creo una nueva variable dentro del constructor.
    {
    }

    static get Instance():Apocalipsis{
        if(!(this._instance)){
            this._instance = new Apocalipsis("HEEELL");
        }
        return this._instance;
    }
}

console.log(Apocalipsis.Instance.nombre);