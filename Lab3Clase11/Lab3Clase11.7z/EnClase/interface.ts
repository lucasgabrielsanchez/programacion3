//let men:Xmen;

//El any permite pasar cualquier cosa.
// function enviarMision(xmen:any){
//     console.log(xmen.nombre);
// }

// let xmen = {
//     nombremal: "Ciclope",//mal
//     //nombre: "Ciclope",//correcto
//     peleasGanadas : 4
// }

// enviarMision(xmen);

//me aseguro de que el objeto que viene tiene un atributo llamado nombrey del tipo string
// function enviarMision(xmen:{nombre:string}){
//     console.log(xmen.nombre);
// }

// let xmen = {
//     //nombremal: "Ciclope",//mal
//     nombre: "Ciclope",//correcto
//     peleasGanadas : 4
// }

// enviarMision(xmen);

interface IXmen{
    nombre:string;
    peleasGanadas:number;
    otroAtributo:string;

    miMetodo():string;
}

function emviarMison(xmen:IXmen){
    console.log(xmen.nombre);
}

let xmen:IXmen;
xmen.nombre = "Ciclope";
xmen.peleasGanadas = 4;
xmen.otroAtributo = "Hola";

enviarMision(xmen);

class Xmen2 implements IXmen
{
    nombre = "Ciclope";
    peleasGanadas = 4;
    otroAtributo = "Hola";
    miMetodo():string
    {
        return "retorno";
    }
}

let xmen2:Xmen2 = new Xmen2();
console.log(xmen2.miMetodo());