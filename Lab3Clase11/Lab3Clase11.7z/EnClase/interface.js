"use strict";
//let men:Xmen;
function emviarMison(xmen) {
    console.log(xmen.nombre);
}
var xmen;
xmen.nombre = "Ciclope";
xmen.peleasGanadas = 4;
xmen.otroAtributo = "Hola";
enviarMision(xmen);
var Xmen2 = /** @class */ (function () {
    function Xmen2() {
        this.nombre = "Ciclope";
        this.peleasGanadas = 4;
        this.otroAtributo = "Hola";
    }
    Xmen2.prototype.miMetodo = function () {
        return "retorno";
    };
    return Xmen2;
}());
var xmen2 = new Xmen2();
console.log(xmen2.miMetodo());
