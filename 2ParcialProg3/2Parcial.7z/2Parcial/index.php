<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require './composer/vendor/autoload.php';
require './clases/AccesoDatos.php';
require './clases/empleadoApi.php';
// require '/clases/MWparaCORS.php';
require './clases/MWparaAutentificar.php';
require './clases/productoApi.php';
require './clases/LoginApi.php';


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->post('/login', \LoginApi::class . ':Login');


$app->group('/empleado', function () {
  
  // $this->get('/traerid/{id}', \empleadoApi::class . ':TraerUnoID');

  // $this->get('/traeremail/{email}', \empleadoApi::class . ':TraerUnoEmail');

  $this->get('/', \empleadoApi::class . ':TraerTodos');

  $this->post('/', \empleadoApi::class . ':CargarUno');

  // $this->get('/cargarunogetheader', \empleadoApi::class . ':CargarUnoGet');

  // $this->delete('/', \empleadoApi::class . ':BorrarUno');

  // $this->put('/', \empleadoApi::class . ':ModificarUno');

  // $this->post('/verificarempleado', \empleadoApi::class . ':VerificarempleadoApi');
     
})->add(\MWparaAutentificar::class . ':VerificarUsuario');
//->add(\MWparaAutentificar::class . ':VerificarUsuario')->add(\MWparaCORS::class . ':HabilitarCORS8080');

$app->group('/producto', function () {

$this->post('/', \ProductoApi::class . ':CargarUno');

// $this->get('/traerusuario/{email}', \ComentarioApi::class . ':TraerUsuario');

// $this->get('/traertitulo/{titulo}', \ComentarioApi::class . ':TraerTitulo');

$this->get('/', \ProductoApi::class . ':TraerTodos');

$this->put('/', \ProductoApi::class . ':ModificarUno');

$this->delete('/', \ProductoApi::class . ':BorrarUno');

//$this->post('/modificarcomentario', \ComentarioApi::class . ':ModificarComentarioApi');

// $this->delete('/', \ComentarioApi::class . ':BorrarComentarioApi');

});//->add(\MWparaAutentificar::class . ':VerificarUsuario');


$app->run();