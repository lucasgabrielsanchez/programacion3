<?php
require_once 'producto.php';
//require_once 'usuario.php';
//require_once 'IApiUsable.php';

class ProductoApi extends Producto //implements IApiUsable
{
    // private static $grilla = '<table class="table">
    // <thead style="background:rgb(14, 26, 112);color:#fff;">
    //     <tr>
    //         <th>  USUARIO </th>
    //         <th>  TITULO     </th>
    //         <th>  COMENTARIO      </th>
    //         <th>  FOTO      </th>
    //     </tr>  
    // </thead>';

    public function CargarUno($request, $response, $args) 
    {

      $ArrayDeParametros = $request->getParsedBody();

      $nombre= $ArrayDeParametros['nombre'];
      $precio= $ArrayDeParametros['precio'];
        
        $miProducto = new Producto();
        
        $miProducto->Nombre = $nombre;
        $miProducto->Precio = $precio;

        $miProducto->InsertarElProductoParametros();
        $response->getBody()->write("<h3>Producto cargado correctamente</h3>");

        return $response;
    }

    public function TraerTodos($request, $response, $args) 
    {
       $todosLosProductos=Producto::TraerTodoLosProductos();
       $response = $response->withJson($todosLosProductos, 200);
       
       return $response;
    }

    public function ModificarUno($request, $response, $args) 
    {                 
        $ArrayDeParametros = $request->getParsedBody();
        $id= $ArrayDeParametros['id'];

        $miProducto = new Producto();

        if(($miProducto = $miProducto->TraerUnProductoID($id)) != false)
        {

            $miProducto->Nombre = $ArrayDeParametros['nombre'];
            $miProducto->Precio = $ArrayDeParametros['precio'];
            $miProducto->ModificarProducto();

            $response->getBody()->write("<p>Producto modificado correctamente</p>");
        }
        else
        {
            $response->getBody()->write("<p>El Producto ingresado es incorrecto</p>");
        }
            
        return $response;
    }

    public function BorrarUno($request, $response, $args) {
        $ArrayDeParametros = $request->getParsedBody();
        $id=$ArrayDeParametros['id'];
        $miProducto= new Producto();
        $miProducto->ID=$id;
        $cantidadDeBorrados=$miProducto->BorrarProducto();

        $objDelaRespuesta= new stdclass();
       $objDelaRespuesta->cantidad=$cantidadDeBorrados;
       if($cantidadDeBorrados>0)
           {
                $objDelaRespuesta->resultado="algo borro!!!";
           }
           else
           {
               $objDelaRespuesta->resultado="no Borro nada!!!";
           }
       $newResponse = $response->withJson($objDelaRespuesta, 200);  
    return $newResponse;
   }

    // public function TraerComentarios($request, $response, $args)
    // {
    //     $todosLosComentarios = Comentario::TraerTodos();

    //     foreach($todosLosComentarios as $comentario)
    //     {
    //       self::$grilla .= "<tr>
    //       <td>".$comentario->Email."</td>
    //       <td>".$comentario->Titulo."</td>
    //       <td>".$comentario->Comentario."</td>
    //       <td><img src=".'.'.$comentario->Path." width='100px' height='100px'/></td>
    //       </tr>";
    //     }

    //     return self::$grilla;
    // }

    // public function TraerUsuario($request, $response, $args)
    // {
    //     $email = $args['email'];
    //     $comentarios = Comentario::TraerComentariosEmail($email);

    //     foreach($comentarios as $comentario)
    //     {
    //       self::$grilla .= "<tr>
    //       <td>".$comentario->Email."</td>
    //       <td>".$comentario->Titulo."</td>
    //       <td>".$comentario->Comentario."</td>
    //       <td><img src=".'../.'.$comentario->Path." width='100px' height='100px'/></td>
    //       </tr>";
    //     }
        
    //     return self::$grilla;
    // }

    // public function TraerTitulo($request, $response, $args)
    // {

    //     $titulo = $args['titulo'];
    //     $comentarios = Comentario::TraerComentariosTitulo($titulo);

    //     foreach($comentarios as $comentario)
    //     {
    //       self::$grilla .= "<tr>
    //       <td>".$comentario->Email."</td>
    //       <td>".$comentario->Titulo."</td>
    //       <td>".$comentario->Comentario."</td>
    //       <td><img src=".'../.'.$comentario->Path." width='100px' height='100px'/></td>
    //       </tr>";
    //     }

    //     return self::$grilla;
    // }

    // public function ModificarComentarioApi($request, $response)
    // {
    //     $ArrayDeParametros = $request->getParsedBody();

    //     $titulo = $ArrayDeParametros['titulo'];
    //     //var_dump($ArrayDeParametros);
    //     $miComentario = new Comentario();

    //     if(($miComentario = $miComentario->TraerComentariosTitulo($titulo)[0]) != false)
    //     {
    //         if (isset($ArrayDeParametros['comentario']))
    //         {
    //             $miComentario->Comentario = $ArrayDeParametros['comentario'];
    //         }

    //             if($request->getUploadedFiles() != NULL)
    //             {

    //                 $archivos = $request->getUploadedFiles();
                    
    //                 $nombreAnterior = $archivos['foto']->getClientFilename();
    
    //                 $extension = pathinfo($nombreAnterior, PATHINFO_EXTENSION);
            
    //                 //mkdir("./imagenesDeComentario/");
            
    //                 $destino="./imagenesDeComentario/".($miComentario->Titulo).".".$extension;
            
    //                 //$ar = fopen("./imagenesDeComentario/usuarios.txt", "w");
    //                 //fwrite($ar,"Hola");
    //                 //fclose($ar);
                
    //                 $archivos['foto']->moveTo($destino);
            
    //                 $miComentario->Path = $destino;
    //             }

    //             $resultado = $miComentario->ModificarComentario();

    //         if($resultado)
    //         {
    //             $response->getBody()->write("<p>Comentario modificado correctamente</p>");
    //         }
    //         else
    //         {
    //             $response->getBody()->write("<p>Error al modificar comentario</p>");
    //         }
            
    //     }
    //     else
    //     {
    //         $response->getBody()->write("<p>El comentario ingresado es incorrecto</p>");
    //     }
	   	
	//    	// $objDelaRespuesta= new stdclass();
	// 	// //var_dump($resultado);
	// 	// $objDelaRespuesta->resultado=$resultado;
	// 	return $response;
    // }

    // public function BorrarComentarioApi($request, $response)
    // {
    //     $ArrayDeParametros = $request->getParsedBody();
    //     $titulo=$ArrayDeParametros['titulo'];

    //     $cantidadDeBorrados = 0;
    //     $objDelaRespuesta= new stdclass();

    //     if(Comentario::TraerComentariosTitulo($titulo) != NULL)
    //     {
    //         $comentario = Comentario::TraerComentariosTitulo($titulo)[0];

    //         $nombreArchivo = pathinfo($comentario->Path, PATHINFO_BASENAME);
            
    //         rename($comentario->Path, "imagenesBorradas/".date("Ymd_His").$nombreArchivo);
    
    //         $miComentario= new Comentario();
    //         $miComentario->Titulo=$titulo;

    //         $cantidadDeBorrados=$miComentario->BorrarComentario();
    
    //         $objDelaRespuesta->cantidad=$cantidadDeBorrados;
    //     }
        
    //     if($cantidadDeBorrados>0)
    //         {
    //             $objDelaRespuesta->resultado="algo borro!!!";
    //         }
    //         else
    //         {
    //             $objDelaRespuesta->resultado="no Borro nada!!!";
    //         }
    //     $newResponse = $response->withJson($objDelaRespuesta, 200);  
    //     return $newResponse;
    // }

}