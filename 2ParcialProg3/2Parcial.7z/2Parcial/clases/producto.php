<?php
class Producto
{
	public $ID;
	public $Nombre;
 	public $Precio;
  	
	public function __construct()
	{

    }
    
    public function InsertarElProductoParametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into productos (nombre,precio)values(:nombre,:precio)");
        $consulta->bindValue(':nombre',$this->Nombre, PDO::PARAM_STR);
        $consulta->bindValue(':precio', $this->Precio, PDO::PARAM_STR);
        $consulta->execute();

        return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}
	
	public static function TraerTodoLosProductos()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select Nombre, Precio from productos");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_CLASS, "Producto");
			//return $consulta->fetchAll();		
	}

	public function ModificarProducto()
	{
		   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		   $consulta =$objetoAccesoDato->RetornarConsulta("
			   update productos 
			   set nombre='$this->Nombre',
			   precio='$this->Precio'
			   WHERE ID='$this->ID'");
		   return $consulta->execute();
	}

	public static function TraerUnProductoID($id) 
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select * from Productos where ID = $id");
			$consulta->execute();
			$ProductoBuscado= $consulta->fetchObject('Producto');
			return $ProductoBuscado;
	}

	public function BorrarProducto()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		   $consulta =$objetoAccesoDato->RetornarConsulta("
			   delete 
			   from productos 				
			   WHERE ID=:id");	
			   $consulta->bindValue(':id',$this->ID, PDO::PARAM_INT);		
			   $consulta->execute();
			   return $consulta->rowCount();
	}

	// public static function TraerComentariosEmail($email) 
	// {
	// 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
	// 	$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios where Email = '$email'");
	// 	$consulta->execute();
	// 	$comentarioBuscado= $consulta->fetchAll(PDO::FETCH_CLASS, "Comentario");
	// 	return $comentarioBuscado;
	// }

	// public static function TraerComentariosTitulo($titulo)
	// {
	// 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 	$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios where Titulo = '$titulo'");
	// 	$consulta->execute();
	// 	$comentarioBuscado= $consulta->fetchAll(PDO::FETCH_CLASS, "Comentario");
	// 	return $comentarioBuscado;		
	// }

	// public static function TraerTodos()
	// {
	// 	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 	$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios");
	// 	$consulta->execute();
	// 	$comentarios = $consulta->fetchAll(PDO::FETCH_CLASS, "Comentario");
	// 	return $comentarios;
	// }

	// public function ModificarComentario()
	// {
	// 	   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 	   $consulta =$objetoAccesoDato->RetornarConsulta("
	// 		   update comentarios 
	// 		   set Comentario='$this->Comentario',
	// 		   Path='$this->Path'
	// 		   WHERE Titulo='$this->Titulo'");
	// 	   return $consulta->execute();
	// }

	// public function BorrarComentario()
	// {
	// 	   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 	   $consulta =$objetoAccesoDato->RetornarConsulta("
	// 		   delete 
	// 		   from comentarios 				
	// 		   WHERE Titulo=:titulo");	
	// 		   $consulta->bindValue(':titulo',$this->Titulo, PDO::PARAM_INT);		
	// 		   $consulta->execute();
	// 		   return $consulta->rowCount();
	// }
}