<?php

require 'Login.php';

class LoginApi extends Login
{
    public function Login($request, $response)
    {
        $ArrayDeParametros = $request->getParsedBody();

        $usuario = $ArrayDeParametros['usuario'];
        $clave = $ArrayDeParametros['clave'];

        $validacion = Login::VerificarUsuario($usuario, $clave);

        if ($validacion->estado == 1) 
        {
            $datos=array('perfil'=>$validacion->usuario->Perfil);
            $token= AutentificadorJWT::CrearToken($datos);
            //$retorno=array('mensaje'=> $validacion->mensaje, 'token'=>$token, 'valido'=>'true', 'usuario'=>$validacion->usuario);
            $retorno=array('mensaje'=> $validacion->mensaje, 'token'=>$token);
            $newResponse = $response->withJson($retorno, 200);
            return $newResponse;
        }
         else 
        {
            $retorno=array('valido'=> 'false', 'mensaje'=>$validacion->mensaje);
            return $response->withJson($retorno, 200);
        }
    }
}
