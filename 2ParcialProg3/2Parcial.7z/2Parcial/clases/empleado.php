<?php
class Empleado
{
	//public $Id;
 	public $Nombre;
  	public $Apellido;
    public $Email;
	public $Foto;
	public $Legajo;
	public $Clave;
	public $Perfil;

	public function __construct()
	{

	}

	 public function InsertarElEmpleadoParametros()
	 {
				$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
				$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into empleados (nombre,apellido,email,foto,legajo,clave,perfil)values(:nombre,:apellido,:email,:foto,:legajo,:clave,:perfil)");
				$consulta->bindValue(':nombre',$this->Nombre, PDO::PARAM_STR);
				$consulta->bindValue(':apellido', $this->Apellido, PDO::PARAM_STR);
                $consulta->bindValue(':email', $this->Email, PDO::PARAM_STR);
                $consulta->bindValue(':foto', $this->Foto, PDO::PARAM_STR);
				$consulta->bindValue(':legajo', $this->Legajo, PDO::PARAM_STR);
				$consulta->bindValue(':clave', $this->Clave, PDO::PARAM_STR);
				$consulta->bindValue(':perfil', $this->Perfil, PDO::PARAM_STR);
				$consulta->execute();		
				return $objetoAccesoDato->RetornarUltimoIdInsertado();
     }


  	public static function TraerTodoLosEmpleados()
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select Nombre, Apellido, Email, Foto, Legajo, Clave, Perfil from empleados");
			$consulta->execute();			
			return $consulta->fetchAll(PDO::FETCH_CLASS, "Empleado");
			//return $consulta->fetchAll();		
	}

	// public static function TraerUnUsuarioID($id) 
	// {
	// 		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 		$consulta =$objetoAccesoDato->RetornarConsulta("select Nombre, Email, Perfil, Edad, Clave from usuarios where ID = $id");
	// 		$consulta->execute();
	// 		$usuarioBuscado= $consulta->fetchObject('Usuario');
	// 		return $usuarioBuscado;		
	// }

	public static function TraerUnEmpleadoEmail($email) 
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("select Nombre, Apellido, Email, Legajo, Clave, Perfil from empleados where email = '$email'");
			$consulta->execute();
			$usuarioBuscado= $consulta->fetchObject('Empleado');
			return $usuarioBuscado;		
	}

	// public static function VerificarUsuario($email,$clave)
	// {
	// 	if(Usuario::TraerUnUsuarioEmail($email) != NULL)
	// 	{
	// 		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
	// 		$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where Email = '$email' AND Clave = '$clave'");
	// 		$consulta->execute();
	// 		$usuarioBuscado= $consulta->fetchObject('Usuario');
	// 		if($usuarioBuscado != NULL)
	// 		{
	// 			return "<h3>Bienvenido</h3>";
	// 		}
	// 		else
	// 		{
	// 			return "<h3>El usuario existe pero la contraseña es incorrecta</h3>";
	// 		}
	// 	}
	// 	else
	// 	{
	// 		return "<h3>El usuario ingresado no existe</h3>";
	// 	}

	// }
			
}