
<?php
require_once 'empleado.php';

    class Login 
    {
        public static function VerificarUsuario($email,$clave)
        {
            $respuesta = new stdClass();

            if(Empleado::TraerUnEmpleadoEmail($email) != NULL)
            {
                $empleadoTraido = Empleado::TraerUnEmpleadoEmail($email);

                if(self::DecodificarClave($clave, $empleadoTraido->Clave))
                {
                    $respuesta->estado = 1;
                    $respuesta->mensaje = "<h3>Bienvenido/a ".$empleadoTraido->Nombre."</h3>";
                    $respuesta->usuario = $empleadoTraido;
                    return $respuesta;
                }
                else
                {
                    $respuesta->estado = 2;
                    $respuesta->mensaje = "<h3>El usuario existe pero la contraseña es incorrecta</h3>";
                    return $respuesta;
                }
            }
            else
            {
                $respuesta->estado = 3;
                $respuesta->mensaje = "<h3>El usuario ingresado no existe</h3>";   
                return $respuesta;
            }
    
        }

        // public static function CodificarClave($clave)
        // {   
        //     $passHash = password_hash($clave, PASSWORD_BCRYPT);

        //     return $passHash;
        // }

        public static function DecodificarClave($clave, $claveCodificada)
        {
            $resultado = password_verify($clave, $claveCodificada);

            return $resultado;
        }
    }
?>