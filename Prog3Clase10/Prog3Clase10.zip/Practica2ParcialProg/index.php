<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require './composer/vendor/autoload.php';
require './clases/AccesoDatos.php';
require './clases/usuarioApi.php';
// require '/clases/MWparaCORS.php';
require './clases/MWparaAutentificar.php';
require './clases/comentarioApi.php';
require './clases/LoginApi.php';


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->post('/login', \LoginApi::class . ':Login');


$app->group('/usuario', function () {
  
  $this->get('/traerid/{id}', \UsuarioApi::class . ':TraerUnoID');

  $this->get('/traeremail/{email}', \UsuarioApi::class . ':TraerUnoEmail');

  $this->get('/', \UsuarioApi::class . ':TraerTodos');

  $this->post('/', \UsuarioApi::class . ':CargarUno');

  $this->get('/cargarunogetheader', \UsuarioApi::class . ':CargarUnoGet');

  $this->delete('/', \UsuarioApi::class . ':BorrarUno');

  $this->put('/', \UsuarioApi::class . ':ModificarUno');

  $this->post('/verificarusuario', \UsuarioApi::class . ':VerificarUsuarioApi');
     
})->add(\MWparaAutentificar::class . ':VerificarUsuario');
//->add(\MWparaAutentificar::class . ':VerificarUsuario')->add(\MWparaCORS::class . ':HabilitarCORS8080');

$app->group('/comentario', function () {

$this->post('/', \ComentarioApi::class . ':CargarUno');

$this->get('/traerusuario/{email}', \ComentarioApi::class . ':TraerUsuario');

$this->get('/traertitulo/{titulo}', \ComentarioApi::class . ':TraerTitulo');

$this->get('/', \ComentarioApi::class . ':TraerComentarios');

$this->post('/modificarcomentario', \ComentarioApi::class . ':ModificarComentarioApi');

$this->delete('/', \ComentarioApi::class . ':BorrarComentarioApi');

})->add(\MWparaAutentificar::class . ':VerificarUsuario');


$app->run();