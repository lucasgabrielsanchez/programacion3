<?php
class Comentario
{
	public $Email;
 	public $Titulo;
  	public $Comentario;
    public $Path;
	
	public function __construct()
	{

    }
    
    public function InsertarElComentarioParametros()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into comentarios (Email,Titulo,Comentario,Path)values(:email,:titulo,:comentario,:path)");
        $consulta->bindValue(':email',$this->Email, PDO::PARAM_STR);
        $consulta->bindValue(':titulo', $this->Titulo, PDO::PARAM_STR);
        $consulta->bindValue(':comentario', $this->Comentario, PDO::PARAM_STR);
        $consulta->bindValue(':path', $this->Path, PDO::PARAM_STR);
        $consulta->execute();

        return $objetoAccesoDato->RetornarUltimoIdInsertado();
    }

	public static function TraerComentariosEmail($email) 
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios where Email = '$email'");
		$consulta->execute();
		$comentarioBuscado= $consulta->fetchAll(PDO::FETCH_CLASS, "Comentario");
		return $comentarioBuscado;
	}

	public static function TraerComentariosTitulo($titulo)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios where Titulo = '$titulo'");
		$consulta->execute();
		$comentarioBuscado= $consulta->fetchAll(PDO::FETCH_CLASS, "Comentario");
		return $comentarioBuscado;		
	}

	public static function TraerTodos()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from comentarios");
		$consulta->execute();
		$comentarios = $consulta->fetchAll(PDO::FETCH_CLASS, "Comentario");
		return $comentarios;
	}

	public function ModificarComentario()
	{
		   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		   $consulta =$objetoAccesoDato->RetornarConsulta("
			   update comentarios 
			   set Comentario='$this->Comentario',
			   Path='$this->Path'
			   WHERE Titulo='$this->Titulo'");
		   return $consulta->execute();
	}

	public function BorrarComentario()
	{
		   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		   $consulta =$objetoAccesoDato->RetornarConsulta("
			   delete 
			   from comentarios 				
			   WHERE Titulo=:titulo");	
			   $consulta->bindValue(':titulo',$this->Titulo, PDO::PARAM_INT);		
			   $consulta->execute();
			   return $consulta->rowCount();
	}
}