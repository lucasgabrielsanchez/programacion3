var foto_string;
$(function () {
    var select = $("#tipo");
    var agregar = $("#btnAgregar");
    var btnPromedio = $("#btnPromedio");
    var select2 = $("#tipo2");
    var checkNombre = $("#checkNombre");
    var checkEdad = $("#checkEdad");
    var checkPatas = $("#checkPatas");
    var checkTipo = $("#checkTipo");
    select2.change(armarTablaFiltrada);
    checkNombre.change(armarTablaFiltrada);
    checkEdad.change(armarTablaFiltrada);
    checkPatas.change(armarTablaFiltrada);
    checkTipo.change(armarTablaFiltrada);
    for (var i = 0; i < 2; i++) {
        select.append("<option value=" + i + ">" + Parcial.sexos[i] + "</option>");
        select2.append("<option value=" + i + ">" + Parcial.sexos[i] + "</option>");
    }
    select2.append("<option value=2>Todos</option>");
    // select.change(function()
    // {
    //     if (select.val() >= 0 && select.val() < 4)
    //     {
    //         $("#patas").val(4);
    //     }
    //     else
    //     {
    //         $("#patas").val(0);
    //     }
    // });
    agregar.click(AgregarEmpleado);
    btnPromedio.click(calcularPromedio);
    refrescarLista();
});
function AgregarEmpleado() {
    var nombre = $("#nombre");
    var edad = $("#edad");
    var patas = $("#patas");
    var tipo = $("#tipo");
    var mascota = new Parcial.Empleado(nombre.val(), edad.val(), patas.val(), tipo.val(), foto_string);
    var MascotasString = localStorage.getItem("Empleados");
    var mascotasArray = [];
    var mascotasArrayAux;
    if (MascotasString == null) {
        //mascotasArray = new Array<practicaMascotas.Mascota>();
        mascotasArray.push(JSON.parse(mascota.toJson()));
    }
    else {
        mascotasArrayAux = JSON.parse(MascotasString);
        for (var indiceLeido in mascotasArrayAux) {
            mascotasArray.push(mascotasArrayAux[indiceLeido]);
        }
        mascotasArray.push(JSON.parse(mascota.toJson()));
    }
    localStorage.setItem("Empleados", JSON.stringify(mascotasArray));
    refrescarLista();
}
function refrescarLista() {
    var tBody = $("#tBody");
    tBody.html("<tr><th>Nombre</th><th>Apellido</th><th>Edad</th><th>Sexo</th><th>Accion</th></tr>");
    var mascotas = JSON.parse(localStorage.getItem("Empleados"));
    if (mascotas != null) {
        for (var index = 0; index < mascotas.length; index++) {
            tBody.append("<tr><td name=n" + index + ">" + mascotas[index].nombre + "</td><td name=a" + index + ">" + mascotas[index].apellido + "</td>" +
                "</td><td name=a" + index + ">" + mascotas[index].edad + "</td>" + "</td><td name=a" + index + ">" + mascotas[index].sexo + "</td>" +
                "<td><input type=button id= " + index + " value=Borrar onclick=borrar(" + index + ")>" +
                "<input type=button id= " + index + " value=Modificar onclick=modificar(" + index + ")></td></tr>");
        }
    }
}
function borrar(id) {
    var mascotas = JSON.parse(localStorage.getItem("Empleados"));
    //El primer parametro del splice indica la posición del array a partir del cual queremos borrar
    //elementos. El segundo indica la cantidad de elementos de ahí en adelante. Como yo solo quiero
    //borrar el elemento de la posición indicada le pongo un 1.
    //Además el splice reordena el array corriendo los índices posteriores hacia abajo porque
    //desapareció el índice que eliminé.
    mascotas.splice(id, 1);
    localStorage.setItem("Empleados", JSON.stringify(mascotas));
    refrescarLista();
}
function modificar(id) {
    var btn = $("#btnAgregar");
    var mascotas = JSON.parse(localStorage.getItem("Empleados"));
    $("#nombre").val(mascotas[id].nombre);
    $("#edad").val(mascotas[id].apellido);
    $("#patas").val(mascotas[id].edad);
    $("#tipo").val(Parcial.sexos[mascotas[id].sexo]);
    btn.attr("value", "modificar");
    btn.off("click", AgregarEmpleado);
    var mod;
    btn.on("click", mod = function () {
        mascotas[id].nombre = $("#nombre").val();
        mascotas[id].apellido = $("#edad").val();
        mascotas[id].edad = $("#patas").val();
        mascotas[id].sexo = Parcial.sexos[$("#tipo").val()];
        localStorage.setItem("Empleados", JSON.stringify(mascotas));
        refrescarLista();
        btn.attr("value", "Agregar");
        btn.off("click", mod);
        btn.on("click", AgregarEmpleado);
    });
}
function empleadosNombre(animales) {
    return animales
        .map(function (animal) {
        return animal.nombre;
    });
}
function empleadosEdad(animales) {
    return animales
        .map(function (animal) {
        return animal.edad;
    });
}
function empleadosApellido(animales) {
    return animales
        .map(function (animal) {
        return animal.apellido;
    });
}
function empleadosTipoMap(animales) {
    return animales
        .map(function (animal) {
        return animal.sexo;
    });
}
function empeladosTipoFilter(animales, sexo) {
    return animales
        .filter(function (animal) {
        return animal.sexo == sexo;
    });
}
function empleadosReduce(animales) {
    if (animales.length > 0) {
        var acumEdad_1 = parseInt(animales[0].edad);
        //hola
        animales
            .reduce(function (previo, actual) {
            acumEdad_1 += parseInt(actual.edad);
            //cantidad += 1;
            return actual;
        });
        return (acumEdad_1 / animales.length);
    }
    else {
        return 0;
    }
}
function armarTablaFiltrada() {
    var checkNombre = $("#checkNombre");
    var checkEdad = $("#checkEdad");
    var checkPatas = $("#checkPatas");
    var checkTipo = $("#checkTipo");
    var select2 = $("#tipo2");
    var tr = "<tr>";
    var tBody2 = $("#tBody2");
    var tHead = $("#tHead");
    tBody2.html("");
    var mascotas = JSON.parse(localStorage.getItem("Empleados"));
    if (select2.val() != 2) {
        mascotas = empeladosTipoFilter(mascotas, (Parcial.sexos[select2.val()]));
    }
    var empleadosNombres = empleadosNombre(mascotas);
    var empleadosEdades = empleadosEdad(mascotas);
    var empleadosApellidos = empleadosApellido(mascotas);
    var empleadosSexos = empleadosTipoMap(mascotas);
    if (checkNombre.is(':checked')) {
        tr += "<th>Nombre</th>";
    }
    if (checkEdad.is(':checked')) {
        tr += "<th>Apellido</th>";
    }
    if (checkPatas.is(':checked')) {
        tr += "<th>Edad</th>";
    }
    if (checkTipo.is(':checked')) {
        tr += "<th>Sexo</th>";
    }
    tr += "</tr>";
    tHead.html(tr);
    for (var index = 0; index < mascotas.length; index++) {
        tr = "<tr>";
        if (checkNombre.is(':checked')) {
            tr += "<td>" + empleadosNombres[index] + "</td>";
        }
        if (checkEdad.is(':checked')) {
            tr += "<td>" + empleadosApellidos[index] + "</td>";
        }
        if (checkPatas.is(':checked')) {
            tr += "<td>" + empleadosEdades[index] + "</td>";
        }
        if (checkTipo.is(':checked')) {
            tr += "<td>" + empleadosSexos[index] + "</td>";
        }
        tr += "</tr>";
        tBody2.append(tr);
    }
}
function calcularPromedio() {
    var select2 = $("#tipo2");
    var txtPromedio = $("#txtPromedio");
    var acumEdad = 0;
    var mascotas = JSON.parse(localStorage.getItem("Empleados"));
    if (select2.val() != 2) {
        mascotas = empeladosTipoFilter(mascotas, (Parcial.sexos[select2.val()]));
    }
    txtPromedio.val(empleadosReduce(mascotas));
}
//IMGN
function encodeImageFileAsURL() {
    var filesSelected = document.getElementById("inputFileToLoad").files;
    if (filesSelected.length > 0) {
        var fileToLoad = filesSelected[0];
        var fileReader = new FileReader();
        fileReader.onload = function (fileLoadedEvent) {
            var srcData = fileLoadedEvent.target.result;
            foto_string = srcData;
        };
        fileReader.readAsDataURL(fileToLoad);
    }
}
