namespace Parcial
{
    export enum sexos
    {
        Masculino,
        Femenino
    }
}