var Parcial;
(function (Parcial) {
    var Persona = /** @class */ (function () {
        function Persona(nombre, apellido, edad) {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
        }
        Persona.prototype.toJson = function () {
            //return JSON.stringify(this);
            return "{\"nombre\" : \"" + this._nombre + "\", \"apellido\" : \"" + this._apellido + "\", \"edad\" : \"" + this._edad + "\", ";
        };
        return Persona;
    }());
    Parcial.Persona = Persona;
})(Parcial || (Parcial = {}));
