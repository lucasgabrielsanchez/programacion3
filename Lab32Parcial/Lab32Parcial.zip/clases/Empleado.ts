
///<reference path="persona.ts"/>
///<reference path="enumerado.ts"/>

namespace Parcial
{
    export class Empleado extends Persona
    {
       //private _id:number;
       private _sexo:number;

       constructor(nombre:string, apellido:string, edad:number, sexo:number)
       {
          super(nombre,apellido,edad);
          this._sexo = sexo;
       }

       toJson():string
       {
           return super.toJson() + `"sexo" : "${sexos[this._sexo]}"}`;
       }
    }
}