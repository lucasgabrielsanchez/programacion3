
///<reference path="persona.ts"/>
///<reference path="enumerado.ts"/>

namespace Parcial
{
    export class Empleado extends Persona
    {
       //private _id:number;
       private _sexo:number;
       private _foto;

       constructor(nombre:string, apellido:string, edad:number, sexo:number, foto:string)
       {
          super(nombre,apellido,edad);
          this._sexo = sexo;
          this._foto = foto;
       }

       toJson():string
       {
           return super.toJson() + `"sexo" : "${sexos[this._sexo]}", "imagen" : "${this._foto}"}`;
       }
    }
}