namespace Parcial
{
    export class Persona
    {
        protected _nombre:string;
        protected _apellido:string;
        protected _edad:number;
        
        constructor(nombre:string, apellido:string, edad:number)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
        }

        toJson():string
        {
            //return JSON.stringify(this);
            return `{"nombre" : "${this._nombre}", "apellido" : "${this._apellido}", "edad" : "${this._edad}", `;
        }
    }

}