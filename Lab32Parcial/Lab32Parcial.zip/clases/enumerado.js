var Parcial;
(function (Parcial) {
    var sexos;
    (function (sexos) {
        sexos[sexos["Masculino"] = 0] = "Masculino";
        sexos[sexos["Femenino"] = 1] = "Femenino";
    })(sexos = Parcial.sexos || (Parcial.sexos = {}));
})(Parcial || (Parcial = {}));
