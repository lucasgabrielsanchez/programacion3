let foto_string;

$(function(){
    let select = $("#tipo");
    let agregar = $("#btnAgregar");
    let btnPromedio = $("#btnPromedio");

    let select2 = $("#tipo2");
    let checkNombre = $("#checkNombre");
    let checkEdad = $("#checkEdad");
    let checkPatas = $("#checkPatas");
    let checkTipo = $("#checkTipo");

    select2.change(armarTablaFiltrada);
    checkNombre.change(armarTablaFiltrada);
    checkEdad.change(armarTablaFiltrada);
    checkPatas.change(armarTablaFiltrada);
    checkTipo.change(armarTablaFiltrada);

    for (var i = 0; i < 2; i++) 
    {
        select.append("<option value="+i+">"+Parcial.sexos[i]+"</option>");
        select2.append("<option value="+i+">"+Parcial.sexos[i]+"</option>");
    }
    
    select2.append("<option value=2>Todos</option>");

    // select.change(function()
    // {
    //     if (select.val() >= 0 && select.val() < 4)
    //     {
    //         $("#patas").val(4);
    //     }
    //     else
    //     {
    //         $("#patas").val(0);
    //     }
    // });

    agregar.click(AgregarEmpleado);
    btnPromedio.click(calcularPromedio);

    refrescarLista();
    
});

function AgregarEmpleado():void
{
    let nombre = $("#nombre");
    let edad = $("#edad");
    let patas = $("#patas");
    let tipo = $("#tipo");

    let mascota:Parcial.Empleado = 
    new Parcial.Empleado(nombre.val(), edad.val(), patas.val(), tipo.val(), foto_string);

    let MascotasString:string|null = localStorage.getItem("Empleados");
    let mascotasArray = [];
    let mascotasArrayAux;

    if (MascotasString == null)
    {
        //mascotasArray = new Array<practicaMascotas.Mascota>();
        mascotasArray.push(JSON.parse(mascota.toJson()));
    }
    else
    {
        mascotasArrayAux = JSON.parse(MascotasString);

        for (let indiceLeido in mascotasArrayAux)
        {
            mascotasArray.push(mascotasArrayAux[indiceLeido]);
        }

        mascotasArray.push(JSON.parse(mascota.toJson()));
       
    }

    localStorage.setItem("Empleados", JSON.stringify(mascotasArray));
    
    refrescarLista();

}

function refrescarLista()
{
    let tBody = $("#tBody");

    tBody.html("<tr><th>Nombre</th><th>Apellido</th><th>Edad</th><th>Sexo</th><th>Accion</th></tr>");

    let mascotas = JSON.parse(localStorage.getItem("Empleados"));

    if(mascotas != null)
    {
        for (var index = 0; index < mascotas.length ; index++)
        {
            tBody.append("<tr><td name=n"+index+">"+mascotas[index].nombre+"</td><td name=a"+index+">"+mascotas[index].apellido+"</td>"+
            "</td><td name=a"+index+">"+mascotas[index].edad+"</td>"+"</td><td name=a"+index+">"+mascotas[index].sexo+"</td>"+
            "<td><input type=button id= "+index+" value=Borrar onclick=borrar("+index+")>"+
            "<input type=button id= "+index+" value=Modificar onclick=modificar("+index+")></td></tr>");
        }          
    }  
}


function borrar(id) 
{
    let mascotas = JSON.parse(localStorage.getItem("Empleados"));

    //El primer parametro del splice indica la posición del array a partir del cual queremos borrar
    //elementos. El segundo indica la cantidad de elementos de ahí en adelante. Como yo solo quiero
    //borrar el elemento de la posición indicada le pongo un 1.
    //Además el splice reordena el array corriendo los índices posteriores hacia abajo porque
    //desapareció el índice que eliminé.
    mascotas.splice(id, 1);
    
    localStorage.setItem("Empleados", JSON.stringify(mascotas));

    refrescarLista();
}

function modificar(id) 
{
    let btn = $("#btnAgregar");
    let mascotas = JSON.parse(localStorage.getItem("Empleados"));

    $("#nombre").val(mascotas[id].nombre);
    $("#edad").val(mascotas[id].apellido);
    $("#patas").val(mascotas[id].edad);
    $("#tipo").val(Parcial.sexos[mascotas[id].sexo]);

    btn.attr("value", "modificar");
    
    btn.off("click", AgregarEmpleado);

    let mod;

    btn.on("click", mod = function()
    {
        mascotas[id].nombre =  $("#nombre").val();
        mascotas[id].apellido =  $("#edad").val();
        mascotas[id].edad =  $("#patas").val();
        mascotas[id].sexo =  Parcial.sexos[$("#tipo").val()];

        localStorage.setItem("Empleados", JSON.stringify(mascotas));

        refrescarLista();

        btn.attr("value", "Agregar");
        btn.off("click", mod);
        btn.on("click", AgregarEmpleado);
    });

}

function empleadosNombre(animales:any)
{
    return animales
    .map(function(animal:any){
        return animal.nombre;
    });
}

function empleadosEdad(animales:any)
{
    return animales
    .map(function(animal:any){
        return animal.edad;
    });
}


function empleadosApellido(animales:any)
{
    return animales
    .map(function(animal:any){
        return animal.apellido;
    });
}

function empleadosTipoMap(animales:any)
{
    return animales
    .map(function(animal:any){
        return animal.sexo;
    });
}

function empeladosTipoFilter(animales:any, sexo:any)
{
    return animales
    .filter(function(animal:any){
        return animal.sexo == sexo;
    });
}

function empleadosReduce(animales:any)
{
    if(animales.length > 0)
    {
        let acumEdad = parseInt(animales[0].edad);
        //hola
        animales
        .reduce(function(previo, actual){
    
            acumEdad += parseInt(actual.edad);
            //cantidad += 1;
            return actual;
        });
    
        return (acumEdad /animales.length);
    }
    else
    {
        return 0;
    }
    
}

function armarTablaFiltrada()
{
    let checkNombre = $("#checkNombre");
    let checkEdad = $("#checkEdad");
    let checkPatas = $("#checkPatas");
    let checkTipo = $("#checkTipo");
    let select2 = $("#tipo2");
    let tr = "<tr>";

    let tBody2 = $("#tBody2");
    let tHead = $("#tHead");

    tBody2.html("");

    let mascotas = JSON.parse(localStorage.getItem("Empleados"));

    if (select2.val() != 2)
    {
        mascotas = empeladosTipoFilter(mascotas,(Parcial.sexos[select2.val()]));
    }
    
    let empleadosNombres=empleadosNombre(mascotas);
    let empleadosEdades=empleadosEdad(mascotas);
    let empleadosApellidos=empleadosApellido(mascotas);
    let empleadosSexos=empleadosTipoMap(mascotas);

    if(checkNombre.is(':checked'))
    {
        tr += "<th>Nombre</th>";
    }

    if(checkEdad.is(':checked'))
    {
        tr += "<th>Apellido</th>";
    }

    if(checkPatas.is(':checked'))
    {
        tr += "<th>Edad</th>";
    }

    if(checkTipo.is(':checked'))
    {
        tr += "<th>Sexo</th>";
    }

    tr += "</tr>";

    tHead.html(tr);

    for (var index = 0; index < mascotas.length ; index++)
    {
        tr = "<tr>";

        if(checkNombre.is(':checked'))
        {
            tr += "<td>"+empleadosNombres[index]+"</td>";
        }
    
        if(checkEdad.is(':checked'))
        {
            tr += "<td>"+empleadosApellidos[index]+"</td>";
        }
    
        if(checkPatas.is(':checked'))
        {
            tr += "<td>"+empleadosEdades[index]+"</td>";
        }
    
        if(checkTipo.is(':checked'))
        {
            tr += "<td>"+empleadosSexos[index]+"</td>";
        }

        tr += "</tr>";
    
        tBody2.append(tr);
    }
}

function calcularPromedio()
{
    let select2 = $("#tipo2");
    let txtPromedio = $("#txtPromedio");
    let acumEdad = 0;

    let mascotas = JSON.parse(localStorage.getItem("Empleados"));
    
    if (select2.val() != 2)
    {
        mascotas = empeladosTipoFilter(mascotas,(Parcial.sexos[select2.val()]));
    }
    
    txtPromedio.val(empleadosReduce(mascotas));
}

//IMGN
function encodeImageFileAsURL() {
    var filesSelected = document.getElementById("inputFileToLoad").files;

    if (filesSelected.length > 0) {
        var fileToLoad = filesSelected[0];
        var fileReader = new FileReader();
        fileReader.onload = function (fileLoadedEvent) {
            var srcData = fileLoadedEvent.target.result;
            foto_string = srcData;
        }
        fileReader.readAsDataURL(fileToLoad);
    }
}



